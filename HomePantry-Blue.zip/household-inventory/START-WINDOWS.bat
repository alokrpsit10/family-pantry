@echo off
echo Starting Household Inventory App...
echo.
echo The app will open in your browser automatically.
echo Keep this window open while using the app.
echo Close this window to stop the app.
echo.
cd /d "%~dp0"
python -m http.server 8765 --bind 127.0.0.1 2>nul || python3 -m http.server 8765 --bind 127.0.0.1
start http://localhost:8765
pause
