#!/bin/bash
echo "Starting Household Inventory App..."
echo ""
echo "The app will open in your browser automatically."
echo "Keep this window open while using the app."
echo "Press Ctrl+C to stop."
echo ""
cd "$(dirname "$0")"
python3 -m http.server 8765 --bind 127.0.0.1 &
SERVER_PID=$!
sleep 1
open http://localhost:8765 2>/dev/null || xdg-open http://localhost:8765 2>/dev/null
wait $SERVER_PID
