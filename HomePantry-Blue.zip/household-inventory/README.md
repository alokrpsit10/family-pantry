# 🏠 Household Inventory App — Setup Guide

## ⚡ FASTEST WAY — Publish Free Online (Recommended)

### Step 1 — Go to Netlify Drop
Open: https://app.netlify.com/drop

### Step 2 — Drag this folder
Drag the entire household-inventory folder onto the Netlify page and wait 10 seconds.

### Step 3 — Get your link
You get a free link like: https://amazing-app-123.netlify.app

### Step 4 — Install on phone
Android: Open in Chrome → 3-dot menu → "Add to Home Screen"
iPhone: Open in Safari → Share button → "Add to Home Screen"

---

## 💻 Run Locally (No Internet)

Windows: Double-click START-WINDOWS.bat
Mac: Right-click START-MAC.command → Open

Do NOT just double-click index.html — it won't work offline that way.

If Python is not installed: https://www.python.org/downloads/
